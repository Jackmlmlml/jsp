create view carview as (select `c`.`id`     AS `carid`,
                               `c`.`userid` AS `userid`,
                               `c`.`goodid` AS `goodid`,
                               `c`.`counts` AS `counts`,
                               `g`.`id`     AS `id`,
                               `g`.`name`   AS `name`,
                               `g`.`price`  AS `price`,
                               `g`.`img`    AS `img`,
                               `g`.`detail` AS `detail`,
                               `g`.`type1`  AS `type1`,
                               `g`.`type2`  AS `type2`,
                               `g`.`kucun`  AS `kucun`
                        from (`xq04`.`car` `c`
                               left join `xq04`.`good` `g` on ((`g`.`id` = `c`.`goodid`))));

